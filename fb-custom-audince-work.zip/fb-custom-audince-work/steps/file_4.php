<?php

require_once __DIR__ . '/vendor/autoload.php';
use FacebookAds\Object\AdAccount;
use FacebookAds\Api;
use FacebookAds\Logger\CurlLogger;

$app_id     = "<APP-ID>";
$app_secret = "<APP-SECRET>";
$access_token = $_SESSION['facebook_access_token']; // Return by step 1 file_1.php
$accounts      = ''; // Return by step 3 file_3.php


foreach( $accounts->data as $account) {

	$account_id = $account->id;

	// Get Custom audiences for specific ad account

	$api = Api::init($app_id, $app_secret, $access_token);
	$api->setLogger(new CurlLogger());
	$fields = array(
		'id',
		'name',
	);
	$params = array(
	);

	$ad_account = new AdAccount($account_id);

	$audience_data = $ad_account->getCustomAudiences(
		$fields,
		$params
	)->getResponse()->getContent();

	$audiences = array();

	if(isset($audience_data['data']) && count($audience_data['data']) > 0 ){
		foreach($audience_data as $key => $value ){
			if('data' === $key) {
				$audiences = $audience_data[$key];
			}
		}
	}

	echo '<pre>';
	print_r($audiences);
	echo '</pre>';

	// return all custom audiences create in current ad account

}