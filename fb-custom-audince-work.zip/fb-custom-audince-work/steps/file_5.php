<?php

require_once __DIR__ . '/vendor/autoload.php';

use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;

$access_token = $_SESSION['facebook_access_token']; // Return by step 1 file_1.php
$audiences    = ''; // Return by step 4 file_4.php

//Add user in custom audiences

if ( isset( $audiences ) && count( $audiences ) > 0 ) {

	foreach ( $audiences as $audience ) {

		$audience_id = $audience['id'];

		$user_emails = array( 'demo@gmail.com' );

		$user_email = array();

		foreach ( $user_emails as $email ) {
			$user_email[] = hash( "sha256", $email );
		}

		$payload = array( 'schema' => 'EMAIL_SHA256', 'data' => array( $user_email ) );


		try {
			// Returns a `Facebook\FacebookResponse` object
			$response = $fb->post( '/' . $audience_id . '/users', array(
				'payload' => $payload,
			), $access_token );

		} catch ( FacebookResponseException $t ) {
			echo 'Graph returned an error: ' . $t->getMessage();
			exit;
		} catch ( FacebookSDKException $t ) {
			echo 'Facebook SDK returned an error: ' . $t->getMessage();
			exit;
		}
		$graphNode = $response->getGraphNode();
	}
}