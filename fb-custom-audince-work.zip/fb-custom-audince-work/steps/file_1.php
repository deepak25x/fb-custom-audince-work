<?php

require_once __DIR__ . '/vendor/autoload.php';
use Facebook\Facebook;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;

$app_id     = "<APP-ID>";
$app_secret = "<APP-SECRET>";

session_start();

$fb = new Facebook( [
	'app_id'                => $app_id, // Replace {app-id} with your app id
	'app_secret'            => $app_secret,
	'default_graph_version' => 'v5.0',
] );

$helper = $fb->getRedirectLoginHelper();

if ( ! isset( $_SESSION['facebook_access_token'] ) ) {
	$_SESSION['facebook_access_token'] = null;
}

if ( ! $_SESSION['facebook_access_token'] ) {
	$helper = $fb->getRedirectLoginHelper();
	try {
		$_SESSION['facebook_access_token'] = (string) $helper->getAccessToken();
	} catch ( FacebookResponseException $e ) {
		// When Graph returns an error
		echo 'Graph returned an error: ' . $e->getMessage();
		exit;
	} catch ( FacebookSDKException $e ) {
		// When validation fails or other local issues
		echo 'Facebook SDK returned an error: ' . $e->getMessage();
		exit;
	}
}

if ( $_SESSION['facebook_access_token'] ) {
	echo $_SESSION['facebook_access_token'];

} else {
	$url         = "<REDIRECT-URL>"; // This url same with given apps OAuth Redirect URIs
	$permissions = [ 'ads_read' ];
	$permissions = [ 'ads_management' ];
	$permissions = [ 'ads_read' ];
	$permissions = [ 'business_management' ];
	$loginUrl    = $helper->getLoginUrl( $url, $permissions );
	echo '<a href="' . $loginUrl . '">Log in with Facebook</a>';
}