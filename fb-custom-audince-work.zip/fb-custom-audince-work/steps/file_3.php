<?php

require_once __DIR__ . '/vendor/autoload.php';
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;

$access_token = $_SESSION['facebook_access_token']; // Return by step 1 file_1.php
$userId       = $user->id; // Return by step 1 file_2.php

if ( $access_token ) {

	## Get All Accounts
	try {
		// Returns a `Facebook\FacebookResponse` object
		$getaccount = $fb->get( '/' . $userId . '/adaccounts/?fields=name,id', $access_token );
	} catch ( FacebookResponseException $e ) {
		echo 'Graph returned an error: ' . $e->getMessage();
		exit;
	} catch ( FacebookSDKException $e ) {
		echo 'Facebook SDK returned an error: ' . $e->getMessage();
		exit;
	}

	$accounts = json_decode( $getaccount->getBody() );

	echo '<pre>';
	print_r($accounts->data);
	echo '</pre>';

	// Return all ad accounts name and id
}