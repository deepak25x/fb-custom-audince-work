<?php

require_once __DIR__ . '/vendor/autoload.php';
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;

$access_token = $_SESSION['facebook_access_token']; // Return by step 1 file_1.php

if ( $access_token ) {

	## Get User ID
	try {
		// Get the \Facebook\GraphNodes\GraphUser object for the current user.
		// If you provided a 'default_access_token', the '{access-token}' is optional.
		$getuser = $fb->get( '/me', $access_token );
	} catch ( FacebookResponseException $e ) {
		// When Graph returns an error
		echo 'Graph returned an error: ' . $e->getMessage();
		exit;
	} catch ( FacebookSDKException $e ) {
		// When validation fails or other local issues
		echo 'Facebook SDK returned an error: ' . $e->getMessage();
		exit;
	}

	$user   = json_decode( $getuser->getGraphUser() );
	$userId = $user->id;

	## Return current user data
}